//
//  video.swift
//  videoFile
//
//  Created by Osmar Coronel on 8/31/15.
//  Copyright © 2015 Osmar Coronel. All rights reserved.
//

import UIKit
import MobileCoreServices
import MessageUI
import AssetsLibrary
import Parse
import AVFoundation

class video: UIViewController,
UINavigationControllerDelegate, UIImagePickerControllerDelegate, MFMailComposeViewControllerDelegate {
    

    @IBOutlet weak var WebView: UIWebView!
    @IBOutlet weak var webOne: UIWebView!
    @IBOutlet weak var webTwo: UIWebView!
    @IBOutlet weak var webThree: UIWebView!
    @IBOutlet weak var webFour: UIWebView!
    @IBOutlet weak var webFive: UIWebView!
    @IBOutlet weak var webSix: UIWebView!
    @IBOutlet weak var ScrollView: UIScrollView!
    @IBOutlet weak var VidOne: UILabel!
    @IBOutlet weak var VidTwo: UILabel!
    @IBOutlet weak var VidThree: UILabel!
    @IBOutlet weak var VidFour: UILabel!
    @IBOutlet weak var VidFive: UILabel!
    @IBOutlet weak var VidSix: UILabel!
    @IBOutlet weak var twitter: UIWebView!


    
    @IBOutlet weak var swipeLabel: UISwipeGestureRecognizer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if UIDevice.currentDevice().userInterfaceIdiom == .Phone{
            self.navigationItem.setRightBarButtonItem(nil, animated: false)
        }
        
        ScrollView.contentSize.width = 2064
        
        refreshButton(self)
        
        //MARK: YOUTUBE VIDEOS
        
        let testObject = PFObject(className: "TestObject")
        testObject["foo"] = "bar"
        testObject.saveInBackgroundWithBlock { (success, error) -> Void in
            print("Object has been saved.")
        }
        
    }
    
    
    
    
    //MARK: CAMERA

    
    /* We will use this variable to determine if the viewDidAppear:
    method of our view controller is already called or not. If not, we will
    display the camera view */
    var beenHereBefore = false
    var controller: UIImagePickerController?


    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        print("Picker was cancelled")
        dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    func isCameraAvailable() -> Bool{
        return UIImagePickerController.isSourceTypeAvailable(.Camera)
    }
    
    func cameraSupportsMedia(mediaType: String,
        sourceType: UIImagePickerControllerSourceType) -> Bool{
            
            let availableMediaTypes =
            UIImagePickerController.availableMediaTypesForSourceType(sourceType) as
                [String]?
            
            if let types = availableMediaTypes{
                for type in types{
                    if type == mediaType{
                        return true
                    }
                }
            }
            
            return false
    }
    
    func doesCameraSupportShootingVideos() -> Bool{
        return cameraSupportsMedia(kUTTypeMovie as String, sourceType: .Camera)
    }
    
    
    
    //MARK: Actions
    
    
    @IBAction func refreshButton(sender: AnyObject) {
        
        //Parse
        //MARK: Video Main
        let query = PFQuery(className:"VideoPlace")
        query.getObjectInBackgroundWithId("LiNsYrnx05") {
            
            
            (obj, error)in
            let _ = obj!
                let game = PFObject(className:"VideoPlace")
            
                let oblec = game["tagName"] //as? String
                
                print(oblec)
                
            
            let nug = obj!.objectForKey("tagName")
            
            
            let YoutubeLink:String = "http://www.youtube.com/embed/\(nug!)"
            
            let width = 528
            let height = 297
            let frame = 0
            let Code:NSString = "<iframe width=\(width) height=\(height) src=\(YoutubeLink) frameborder=\(frame) allowfullscreen></iframe>";
            self.WebView.loadHTMLString(Code as String, baseURL: nil)
            print(YoutubeLink)
            
        }
        //MARK: Video 1
        let dink = PFQuery(className:"VideoPlace")
        dink.getObjectInBackgroundWithId("5HBM9T1ZIb") {
            
            
            (obj, error)in
           let _ = obj!
                let game = PFObject(className:"VideoPlace")
            
                let oblec = game["tagName"] //as? String
                
                print(oblec)
            
            
            let nug = obj!.objectForKey("tagName")
            
            let v1 = obj!.objectForKey("videoName")
            
            self.VidOne.text = v1 as? String
            
            
            let YoutubeLink:String = "http://www.youtube.com/embed/\(nug!)"
            let width = 320
            let height = 180
            let frame = 10
            let Code:NSString = "<iframe width=\(width) height=\(height) src=\(YoutubeLink) frameborder=\(frame) allowfullscreen></iframe>";
            self.webOne.loadHTMLString(Code as String, baseURL: nil)
            print(YoutubeLink)
            
            
        }
        //MARK: Video 2
        let doo = PFQuery(className:"VideoPlace")
        doo.getObjectInBackgroundWithId("I8Fu3AC1Ey") {
            
            
            (obj, error)in
            let _ = obj!
                let game = PFObject(className:"VideoPlace")
            
                let oblec = game["tagName"] //as? String
                
                print(oblec)
                
            
            let nug = obj!.objectForKey("tagName")
            
            let v1 = obj!.objectForKey("videoName")
            
            self.VidTwo.text = v1 as? String
            
            let YoutubeLink:String = "http://www.youtube.com/embed/\(nug!)"
            let width = 320
            let height = 180
            let frame = 10
            let Code:NSString = "<iframe width=\(width) height=\(height) src=\(YoutubeLink) frameborder=\(frame) allowfullscreen></iframe>";
            self.webTwo.loadHTMLString(Code as String, baseURL: nil)
            print(YoutubeLink)
            
            
        }
        //MARK: Video 3
        let rife = PFQuery(className:"VideoPlace")
        rife.getObjectInBackgroundWithId("T5Dl0AidBU") {
            
            
            (obj, error)in
            let _ = obj!
                let game = PFObject(className:"VideoPlace")
            
                let oblec = game["tagName"] //as? String
                
                print(oblec)
           
        
            
            let nug = obj!.objectForKey("tagName")
            
            let v1 = obj!.objectForKey("videoName")
            
            self.VidThree.text = v1 as? String
            
            let YoutubeLink:String = "http://www.youtube.com/embed/\(nug!)"
            let width = 320
            let height = 180
            let frame = 10
            let Code:NSString = "<iframe width=\(width) height=\(height) src=\(YoutubeLink) frameborder=\(frame) allowfullscreen></iframe>";
            self.webThree.loadHTMLString(Code as String, baseURL: nil)
            print(YoutubeLink)
            
            
        }
        //MARK: Video 4
        let flin = PFQuery(className:"VideoPlace")
        flin.getObjectInBackgroundWithId("L5Fppoovlh") {
            
            
            (obj, error)in
            let _ = obj!
                let game = PFObject(className:"VideoPlace")
            
                let oblec = game["tagName"] //as? String
                
                print(oblec)
                
           
            
            
            let nug = obj!.objectForKey("tagName")
            
            let v1 = obj!.objectForKey("videoName")
            
            self.VidFour.text = v1 as? String
            
            let YoutubeLink:String = "http://www.youtube.com/embed/\(nug!)"
            let width = 320
            let height = 180
            let frame = 10
            let Code:NSString = "<iframe width=\(width) height=\(height) src=\(YoutubeLink) frameborder=\(frame) allowfullscreen></iframe>";
            self.webFour.loadHTMLString(Code as String, baseURL: nil)
            print(YoutubeLink)
            
            
        }
        // MARK: Video 5
        let mama = PFQuery(className:"VideoPlace")
        mama.getObjectInBackgroundWithId("FdPrVJWxdv") {
            
            
            (obj, error)in
           let _ = obj!
            
            
                
            
            let nug = obj!.objectForKey("tagName")
            
            let v1 = obj!.objectForKey("videoName")
            
            self.VidFive.text = v1 as? String
            
            let YoutubeLink:String = "http://www.youtube.com/embed/\(nug!)"
            let width = 320
            let height = 180
            let frame = 10
            let Code:NSString = "<iframe width=\(width) height=\(height) src=\(YoutubeLink) frameborder=\(frame) allowfullscreen></iframe>";
            self.webFive.loadHTMLString(Code as String, baseURL: nil)
            print(YoutubeLink)
            
            
        }
        // MARK: Video 6
        let gor = PFQuery(className:"VideoPlace")
        gor.getObjectInBackgroundWithId("35J7hDEWYz") {
            
            
            (obj, error)in
            let _ = obj!
            let game = PFObject(className:"VideoPlace")
            let oblec = game["tagName"] //as? String
                
            print(oblec)
            
            
            let nug = obj!.objectForKey("tagName")
            
            let v1 = obj!.objectForKey("videoName")
            
            self.VidSix.text = v1 as? String
            
            let YoutubeLink:String = "http://www.youtube.com/embed/\(nug!)"
            let width = 320
            let height = 180
            let frame = 10
            let Code:NSString = "<iframe width=\(width) height=\(height) src=\(YoutubeLink) frameborder=\(frame) allowfullscreen></iframe>";
            self.webSix.loadHTMLString(Code as String, baseURL: nil)
            print(YoutubeLink)
            
            
        }
        
        
        
        let bam:String = "https://twitter.com/McCarthyMBC"
        /*let widgetid:String = "651609185487036416"
        let src = "://platform.twitter.com/widgets.js"
        let twit = "twitter-timeline"
        let script = "script"
        let twittwo = "twitter-wjs"
        let Code:NSString = "<a class=\(twit) href=\(bam) data-widget-id=\(widgetid)>Tweets by @McCarthyMBC</a><script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+\(src);fjs.parentNode.insertBefore(js,fjs);}}(document,\(script),\(twittwo));</script>"*/
        
        let Code:NSString = "<iframe src=\(bam)</iframe>";
        
        self.twitter.loadHTMLString(Code as String , baseURL: nil)
        
        

    }

    
    @IBAction func camera(sender: AnyObject) {
        if beenHereBefore{
            /* Only display the picker once as the viewDidAppear: method gets
            called whenever the view of our view controller gets displayed */
            
        } else {
            beenHereBefore = true
        }
       
        
        if isCameraAvailable() && doesCameraSupportShootingVideos() && UIDevice.currentDevice().userInterfaceIdiom == .Pad{
            
            controller = UIImagePickerController()
            
            if let theController = controller{
                
                
                theController.sourceType = .Camera
                
                theController.mediaTypes = [kUTTypeMovie as String]
                
                theController.allowsEditing = true
                theController.delegate = self

                
                /* Record in high quality */
                theController.videoQuality = .TypeMedium
                
                /* Only allow 30 seconds of recording */
                theController.videoMaximumDuration = 10.0
                
                presentViewController(theController, animated: true, completion: nil)
            }
            
        } else {
            print("Camera is not available")
            
        }
    }
    
    
    
    
    
    // MARK: MFMailComposeViewControllerDelegate
    

        func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
            self.dismissViewControllerAnimated(true, completion: nil)
        }
    
    
    
    
    func imagePickerController(picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String: AnyObject]){
            
        
            
        
            
            if (MFMailComposeViewController.canSendMail()) {
                
                

                let mailComposerVC = MFMailComposeViewController()
                mailComposerVC.mailComposeDelegate = self // Extremely important to set the --mailComposeDelegate-- property, NOT the --delegate-- property
            
                mailComposerVC.setToRecipients(["mbcnewsapp@gmail.com"])
                mailComposerVC.setSubject("Student Cam")
                mailComposerVC.setMessageBody("Here is a video of what I saw in school. \n \n", isHTML: false)
                
                let mediaType = info[UIImagePickerControllerMediaType] as! NSString
                
                if mediaType.isEqualToString(kUTTypeMovie as NSString as String)
                {
                    let videoPath = info[UIImagePickerControllerMediaURL] as! NSURL
                    print(videoPath)
                    
                    
                    if let fileData = NSData(contentsOfURL: videoPath) {
                        
                       
                    print(fileData)
                        
                       
                        mailComposerVC.addAttachmentData(fileData, mimeType: ".MOV", fileName: "capturedvideo.mov")
                    }
                    
                    
                    print(videoPath)
                    self.dismissViewControllerAnimated(true, completion: nil)
                    
                    
                    
                }
                
              
                
                self.presentViewController(mailComposerVC, animated: true, completion: nil)
    
                
            } else {
                self.showSendMailErrorAlert()
            }
            
            
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertView(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", delegate: self, cancelButtonTitle: "OK")
        sendMailErrorAlert.show()
    }
    
    
    
    
}
