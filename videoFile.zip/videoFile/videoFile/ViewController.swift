//
//  ViewController.swift
//  videoFile
//
//  Created by Osmar Coronel on 8/31/15.
//  Copyright © 2015 Osmar Coronel. All rights reserved.
//

/*import UIKit
import MobileCoreServices


class ViewController: UIViewController,
UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    
    @IBOutlet weak var myImageView: UIImageView!
    
    /* We will use this variable to determine if the viewDidAppear:
    method of our view controller is already called or not. If not, we will
    display the camera view */
    var beenHereBefore = false
    var controller: UIImagePickerController?
    
    func imagePickerController(picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String: AnyObject]){
            
            print("Picker returned successfully")
            
            let mediaType:AnyObject? = info[UIImagePickerControllerMediaType]
            
            if let type:AnyObject = mediaType{
                
                if type is String{
                    let stringType = type as! String
                    
                    if stringType == kUTTypeMovie as String{
                        let urlOfVideo = info[UIImagePickerControllerMediaURL] as? NSURL
                        if let url = urlOfVideo{
                            
                            print("Url of video = \(url)")
                            
                            var dataReadingError: NSError?
                            let videoData: NSData?
                            do {
                                videoData = try NSData(contentsOfURL: url,
                                    options: .MappedRead)
                            } catch let error as NSError {
                                dataReadingError = error
                                videoData = nil
                            }
                            
                            if videoData!.length == 0{
                                /* We were able to read the data */
                                print("Successfully loaded the data")
                            } else {
                                /* We failed to read the data. Use the dataReadingError
                                variable to determine what the error is */
                                if let error = dataReadingError{
                                    print("Failed to load the data with error  = \(error)")
                                }
                            }
                            
                        }
                    }
                    
                   // var chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
                    //myImageView.contentMode = .ScaleAspectFit //3
                   // myImageView.image = chosenImage //4
                   // dismissViewControllerAnimated(true, completion: nil) //5
                    
                }
            }
            
            picker.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        print("Picker was cancelled")
        dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    func isCameraAvailable() -> Bool{
        return UIImagePickerController.isSourceTypeAvailable(.Camera)
    }
    
    func cameraSupportsMedia(mediaType: String,
        sourceType: UIImagePickerControllerSourceType) -> Bool{
            
            let availableMediaTypes =
            UIImagePickerController.availableMediaTypesForSourceType(sourceType) as
                [String]?
            
            if let types = availableMediaTypes{
                for type in types{
                    if type == mediaType{
                        return true
                    }
                }
            }
            
            return false
    }
    
    func doesCameraSupportShootingVideos() -> Bool{
        return cameraSupportsMedia(kUTTypeMovie as String, sourceType: .Camera)
    }
    
    /* 1 */
    //    override func viewDidAppear(animated: Bool) {
    //      super.viewDidAppear(animated)
    //
    //      if beenHereBefore{
    //        /* Only display the picker once as the viewDidAppear: method gets
    //        called whenever the view of our view controller gets displayed */
    //        return;
    //      } else {
    //        beenHereBefore = true
    //      }
    //
    //      if isCameraAvailable() && doesCameraSupportShootingVideos(){
    //
    //        controller = UIImagePickerController()
    //
    //        if let theController = controller{
    //          theController.sourceType = .Camera
    //
    //          theController.mediaTypes = [kUTTypeMovie as String]
    //
    //          theController.allowsEditing = true
    //          theController.delegate = self
    //
    //          presentViewController(theController, animated: true, completion: nil)
    //        }
    //
    //      } else {
    //        print("Camera is not available")
    //      }
    //
    //    }
    
    
    
    @IBAction func camera(sender: AnyObject) {
        if beenHereBefore{
            /* Only display the picker once as the viewDidAppear: method gets
            called whenever the view of our view controller gets displayed */
            return;
        } else {
            beenHereBefore = true
        }
        
        if isCameraAvailable() && doesCameraSupportShootingVideos(){
            
            controller = UIImagePickerController()
            
            if let theController = controller{
                theController.sourceType = .Camera
                
                theController.mediaTypes = [kUTTypeMovie as String]
                
                theController.allowsEditing = true
                theController.delegate = self
                
                /* Record in high quality */
                theController.videoQuality = .TypeHigh
                
                /* Only allow 30 seconds of recording */
                theController.videoMaximumDuration = 10.0
                
                
                presentViewController(theController, animated: false, completion: nil)
            }
            
        } else {
            print("Camera is not available")
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }
    
    
    /*override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        if beenHereBefore{
            /* Only display the picker once as the viewDidAppear: method gets
            called whenever the view of our view controller gets displayed */
            return;
        } else {
            beenHereBefore = true
        }
        
        if isCameraAvailable() && doesCameraSupportShootingVideos(){
            
            controller = UIImagePickerController()
            
            if let theController = controller{
                theController.sourceType = .Camera
                
                theController.mediaTypes = [kUTTypeMovie as String]
                
                theController.allowsEditing = true
                theController.delegate = self
                
                /* Record in high quality */
                theController.videoQuality = .TypeHigh
                
                /* Only allow 30 seconds of recording */
                theController.videoMaximumDuration = 10.0
                
                
                presentViewController(theController, animated: true, completion: nil)
            }
            
        } else {
            print("Camera is not available")
        }
        
    }*/
    
    
}*/

